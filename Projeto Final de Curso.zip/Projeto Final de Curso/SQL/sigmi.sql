drop database db_sigmi;
create database db_sigmi;
use  db_sigmi;

CREATE TABLE tbEndereco (
	id_end int unique PRIMARY KEY AUTO_INCREMENT,
    endereco_rua varchar(80),
    endereco_num varchar(8),
    endereco_bairro varchar(20),    
    endereco_cep varchar(12),
    endereco_cidade varchar(20),
    endereco_estado varchar (15),
    endereco_complemento varchar(20)    
    );

CREATE TABLE tbEmpresa (
	id_emp int unique PRIMARY KEY AUTO_INCREMENT,
    cnpj_emp varchar(20),
    razao_social_emp varchar (80),
    nome_fantasia_emp varchar(80),
    emp_telefone varchar(20),
    emp_email varchar(80),
    endereco int,
    
    FOREIGN KEY (endereco) REFERENCES tbEndereco(id_end)      
    );    

CREATE TABLE tbUsuario (
    id_user int unique PRIMARY KEY AUTO_INCREMENT,
    email varchar(80),
    nome_user varchar(20),
    senha varchar(15),
    id_empresa int not null,
    
    FOREIGN KEY (id_empresa) REFERENCES tbEmpresa(id_emp)    
);


CREATE TABLE tbTecnico (
	id_tec int unique PRIMARY KEY AUTO_INCREMENT,
    nome_tecnico varchar(80)        
);

CREATE TABLE tbTecEmp (
	id_tecnico int,
	id_empresa int,
    FOREIGN KEY (id_tecnico) REFERENCES tbTecnico(id_tec),    
    FOREIGN KEY (id_empresa) REFERENCES tbEmpresa(id_emp)
);


CREATE TABLE tbCliente (
	id_cli int unique PRIMARY KEY AUTO_INCREMENT,
    tipo_cliente ENUM('PF', 'PJ') NOT NULL,
    nome varchar(80),    
    cpf varchar(18),    
    email varchar(80),
    cnpj varchar(20),
    razao_social varchar (80),
    nome_fantasia varchar(80),
    telefone varchar(20),    
    
    endereco int,    
    
    FOREIGN KEY (endereco) REFERENCES tbEndereco(id_end)    
    
    );    
    
CREATE TABLE tbStatus (
	id_stat int unique PRIMARY KEY AUTO_INCREMENT,
	nome_status enum ('Entrada','Analise','Manutencao','Concluido')  not null
);

INSERT INTO tbStatus (nome_status) VALUES ('Entrada');
INSERT INTO tbStatus (nome_status) VALUES ('Analise');
INSERT INTO tbStatus (nome_status) VALUES ('Manutencao');
INSERT INTO tbStatus (nome_status) VALUES ('Concluido');

CREATE TABLE tbServicos (
	id_serv int unique PRIMARY KEY AUTO_INCREMENT,
    nome_servico varchar(30) 
);

CREATE TABLE tbEquipamento (
	id_equip int unique PRIMARY KEY AUTO_INCREMENT,
	nome_equipamento varchar(80),
	num_serie varchar(30),
	memoria varchar(10),
	armazenamento varchar(80),
	processador varchar(80),
    observacoes text,
	id_cliente int,	
    FOREIGN KEY (id_cliente) REFERENCES tbCliente(id_cli)	
);

CREATE TABLE tbOrdemServico (
	id_os int unique PRIMARY KEY AUTO_INCREMENT,
	data_inicio date,
	data_final date,
    id_status int,
    id_tecnico int,
    id_cliente int,   
    evolucao text,
        
	FOREIGN KEY (id_status) REFERENCES tbStatus(id_stat),
    FOREIGN KEY (id_tecnico) REFERENCES tbTecnico(id_tec),	
	FOREIGN KEY (id_cliente) REFERENCES tbCliente(id_cli)	
);

CREATE TABLE tbOsServ(
	id_servico int,
    id_ordemdeservico int,
    
    FOREIGN KEY (id_servico) REFERENCES tbServico(id_serv),	
	FOREIGN KEY (id_ordemdeservico) REFERENCES tbOrdemServico(id_os)    
);

CREATE TABLE tbOsEquip(
	id_ordemdeservico int,
    id_equipamento int,
    FOREIGN KEY (id_ordemdeservico) REFERENCES tbOrdemServico(id_os),
    FOREIGN KEY (id_equipamento) REFERENCES tbEquipamento(id_equip)	 
);


INSERT INTO tbUsuario (email, nome_user, senha, id_empresa)
Values ('empresa@empresa','admin','admin',1) ;

SELECT * FROM tbUsuario;

INSERT INTO tbEmpresa (cnpj_emp, razao_social_emp, nome_fantasia_emp, emp_telefone, emp_email,endereco )
VALUES
('11111111000101','EMPRESA TESTE','SIGMI','33333333','sigmi@sigmi.com.br',1);

SELECT * FROM tbEmpresa;
INSERT INTO tbendereco(endereco_rua,endereco_num,endereco_bairro,endereco_cep,endereco_cidade,endereco_estado,endereco_complemento)
VALUES 
('Rua teste',500,'Jardim Claudia','80000000','Pinhais','PR','Casa 1000');

SELECT * FROM tbEndereco;

SELECT * FROM tbEmpresa CROSS JOIN tbEndereco;

SELECT tbEmpresa.razao_social_emp,tbEmpresa.cnpj_emp,tbEmpresa.nome_fantasia_emp,tbEmpresa.emp_email,tbEndereco.endereco_rua,
tbEndereco.endereco_num,tbEndereco.endereco_bairro,tbEndereco.endereco_cep,tbEndereco.endereco_cidade,tbEndereco.endereco_estado,
tbEndereco.endereco_complemento
FROM tbEmpresa
JOIN tbEndereco ON tbEmpresa.endereco = tbEndereco.id_end;

SELECT * FROM tbEndereco;
SELECT * FROM tbCliente;
SELECT id_cli, nome, razao_social FROM tbCliente;
SELECT * FROM tbEquipamento;
SELECT * FROM tbTecnico;
SELECT * FROM tbordemservico;


SELECT * FROM tbOrdemServico;
SELECT * FROM tbStatus;

INSERT INTO tbStatus (nome_status) VALUES ('Analise');
SELECT * FROM tbStatus;
DESCRIBE tbStatus;




SELECT os.id_os, os.data_inicio, os.data_final, s.nome_status, t.nome_tecnico, c.nome, os.evolucao
FROM tbOrdemServico os
LEFT JOIN tbStatus s ON os.id_status = s.id_stat
LEFT JOIN tbTecnico t ON os.id_tecnico = t.id_tec
LEFT JOIN tbCliente c ON os.id_cliente = c.id_cli
ORDER BY os.data_inicio DESC;


SELECT os.id_os, os.data_inicio, os.data_final, s.nome_status, t.nome_tecnico, c.nome, os.evolucao
        FROM tbOrdemServico os
        LEFT JOIN tbStatus s ON os.id_status = s.id_stat
        LEFT JOIN tbTecnico t ON os.id_tecnico = t.id_tec
        LEFT JOIN tbCliente c ON os.id_cliente = c.id_cli
        ORDER BY os.data_inicio DESC;
        
        
SELECT os.id_os, os.data_inicio, os.data_final, s.nome_status, t.nome_tecnico, c.nome, os.evolucao
FROM tbOrdemServico os
LEFT JOIN tbStatus s ON os.id_status = s.id_stat
LEFT JOIN tbTecnico t ON os.id_tecnico = t.id_tec
LEFT JOIN tbCliente c ON os.id_cliente = c.id_cli
ORDER BY os.data_inicio DESC;










    
    














