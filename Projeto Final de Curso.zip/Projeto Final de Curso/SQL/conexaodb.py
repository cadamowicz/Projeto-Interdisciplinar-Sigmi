import mysql.connector


def conexao():
    global conn
    global cursor
    
    conn=mysql.connector.connect (
        host='localhost',
        database='db_sigmi',
        user='root',
        password=''
        )

    if conn.is_connected():    #busca o db selecionado e imprime se deu certo a conexao
        
        cursor=conn.cursor()
        cursor.execute("select database();")
        linha=cursor.fetchone()
        print("Conectado com sucesso", linha)


    
def endconexao():
    if conn.is_connected():      # fecha o db
        cursor.close()
        conn.close()
        print("Conexao encerrada")
    
def verificalogin(nome, senha):
    conexao()
    try:
        consultaloginsql = "SELECT * FROM tbUsuario"
        cursor = conn.cursor()
        cursor.execute(consultaloginsql)
        usuarios = cursor.fetchall()
        
        for usuario in usuarios:
            if nome == usuario[2] and usuario[3] == senha:
                return True
        return False  # Retornar False fora do loop
    finally:
        endconexao()
    
def buscadadosperfil():
     #Buscar dados do banco de dados  
    conexao()
    try:
    
        buscadadostbemptbend='''SELECT tbEmpresa.razao_social_emp,tbEmpresa.cnpj_emp,tbEmpresa.nome_fantasia_emp,tbEndereco.endereco_rua,
            tbEndereco.endereco_num,tbEndereco.endereco_cep,tbEndereco.endereco_bairro,tbEndereco.endereco_cidade,tbEndereco.endereco_estado,
            tbEndereco.endereco_complemento
            FROM tbEmpresa
            JOIN tbEndereco ON tbEmpresa.endereco = tbEndereco.id_end'''
        cursor=conn.cursor()
        cursor.execute(buscadadostbemptbend)
        buscadados = cursor.fetchall()   
        return buscadados
    finally:
        endconexao()
    

# Função para inserir cliente no banco de dados
def inserir_cliente(tipo_cliente, nome, cpf, email, telefone, cnpj, razao_social, nome_fantasia, endereco_rua, endereco_num, endereco_bairro, endereco_cep, endereco_cidade, endereco_estado, endereco_complemento):
    conexao()
    sucesso = False  # Variável para capturar sucesso da operação
    
    try:
        cursor = conn.cursor()

        # Insere dados do endereço na tabela tbEndereco
        consulta_endereco = "INSERT INTO tbEndereco (endereco_rua, endereco_num, endereco_bairro, endereco_cep, endereco_cidade, endereco_estado, endereco_complemento) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        valores_endereco = (endereco_rua, endereco_num, endereco_bairro, endereco_cep, endereco_cidade, endereco_estado, endereco_complemento)
        cursor.execute(consulta_endereco, valores_endereco)
        
        # Obtém o ID do endereço recém-inserido
        id_endereco = cursor.lastrowid
        
        # Insere dados do cliente na tabela tbCliente
        if tipo_cliente == 'fisica':
            consulta_cliente = "INSERT INTO tbCliente (tipo_cliente, nome, cpf, email, telefone, endereco) VALUES (%s, %s, %s, %s, %s, %s)"
            valores_cliente = ('PF', nome, cpf, email, telefone, id_endereco)
        elif tipo_cliente == 'juridica':
            consulta_cliente = "INSERT INTO tbCliente (tipo_cliente, razao_social, cnpj, nome_fantasia, email, telefone, endereco) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            valores_cliente = ('PJ', razao_social, cnpj, nome_fantasia, email, telefone, id_endereco)
        
        cursor.execute(consulta_cliente, valores_cliente)
        
        # Confirmar mudanças
        conn.commit()
        sucesso = True
        print("Dados do cliente e endereço inseridos com sucesso.")
    except mysql.connector.Error as e:
        print("Erro ao inserir dados do cliente:", e)
    finally:
        endconexao()
        return sucesso  # Retorna o status da operação


def busca_clientes(query):
    conexao()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id_cli, nome, razao_social FROM tbCliente WHERE nome LIKE %s OR razao_social LIKE %s", (f"%{query}%", f"%{query}%"))
        results = cursor.fetchall()
        return [{"id_cli": row[0], "nome": row[1] or row[2]} for row in results]
    finally:
        endconexao()

def insere_equipamento(nome_equipamento, num_serie, memoria, armazenamento, processador, observacoes, id_cliente):
    conexao()
    try:
        cursor.execute("""
            INSERT INTO tbEquipamento (nome_equipamento, num_serie, memoria, armazenamento, processador, observacoes, id_cliente)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (nome_equipamento, num_serie, memoria, armazenamento, processador, observacoes, id_cliente))
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        endconexao()

def insere_tecnico(nome_tecnico):
    conexao()
    try:
        cursor = conn.cursor()
        consulta_tecnico = "INSERT INTO tbTecnico (nome_tecnico) VALUES (%s)"
        valores_tecnico = (nome_tecnico,)
        cursor.execute(consulta_tecnico, valores_tecnico)
        conn.commit()
        print("Técnico inserido com sucesso.")
        return True  # Retorna True em caso de sucesso
    except mysql.connector.Error as e:
        print("Erro ao inserir técnico:", e)
        return False  # Retorna False em caso de erro
    finally:
        endconexao()


def busca_equipamentos(query):
    conexao()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT id_equip, nome_equipamento FROM tbEquipamento WHERE nome_equipamento LIKE %s", (f"%{query}%",))        
        results = cursor.fetchall()
        return [{"id_equip": row[0], "nome_equipamento": row[1]} for row in results]
    finally:
        
        endconexao()

# Função para buscar técnicos no banco de dados
def busca_tecnicos(query):
    conexao()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id_tec, nome_tecnico FROM tbTecnico WHERE nome_tecnico LIKE %s", (f"%{query}%",))        
        results = cursor.fetchall()
        return [{"id_tec": row[0], "nome_tecnico": row[1]} for row in results]
    finally:
        endconexao()

def inserir_ordem_servico(data_inicio, data_final, cliente_id, equipamento_id, tecnico_id, status, evolucao):
    conexao()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO tbOrdemServico (data_inicio, data_final, id_status, id_tecnico, id_cliente, evolucao)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (data_inicio, data_final, status, tecnico_id, cliente_id, evolucao))
    conn.commit()
    conn.close()

def buscar_ordens_servico():
    conexao()
    query = """
        SELECT os.id_os, os.data_inicio, os.data_final, s.nome_status, t.nome_tecnico, c.nome, os.evolucao
        FROM tbOrdemServico os
        LEFT JOIN tbStatus s ON os.id_status = s.id_stat
        LEFT JOIN tbTecnico t ON os.id_tecnico = t.id_tec
        LEFT JOIN tbCliente c ON os.id_cliente = c.id_cli
        ORDER BY os.data_inicio ASC;
    """
    cursor.execute(query)
    ordens = cursor.fetchall()
    endconexao()
    
    
    print("Dados retornados pela consulta:", ordens)
    
    return ordens


def atualizar_status_ordem_servico(id_os, novo_status):
    conexao()
    query = """
        UPDATE tbOrdemServico
        SET id_status = %s
        WHERE id_os = %s
    """
    cursor.execute(query, (novo_status, id_os))
    conn.commit()
    endconexao()






    
    

    

    


        