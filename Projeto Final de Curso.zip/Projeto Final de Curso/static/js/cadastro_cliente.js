function atualizarFormulario() {
    console.log("Evento onchange acionado!");
    var tipoCliente = document.getElementById('tipocliente').value;
    console.log("Valor selecionado no campo 'tipo-cliente':", tipoCliente);
    var formFisica = document.getElementById('form-fisica');
    var formJuridica = document.getElementById('form-juridica');

    formFisica.classList.add('hidden');
    formJuridica.classList.add('hidden');

    if (tipoCliente == 'fisica') {
        formFisica.classList.remove('hidden');
    } else if (tipoCliente == 'juridica') {
        formJuridica.classList.remove('hidden');
    }
}