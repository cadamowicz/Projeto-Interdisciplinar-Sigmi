function buscarCliente(query) {
    if (query.length === 0) {
        document.getElementById('sugestoesClientes').innerHTML = '';
        return;
    }
    fetch(`/busca_cliente?q=${query}`)
        .then(response => response.json())
        .then(data => {
            let sugestoes = data.map(cliente => `<div onclick="selecionarCliente('${cliente.nome}', ${cliente.id_cli})">${cliente.nome}</div>`).join('');
            document.getElementById('sugestoesClientes').innerHTML = sugestoes;
        });
}

function selecionarCliente(nomeCliente, idCliente) {
    document.getElementById('cliente').value = nomeCliente;
    document.getElementById('clienteId').value = idCliente;
    document.getElementById('sugestoesClientes').innerHTML = '';
}

function buscarEquipamento(query) {
    if (query.length === 0) {
        document.getElementById('sugestoesEquipamentos').innerHTML = '';
        return;
    }
    fetch(`/busca_equipamento?q=${query}`)
        .then(response => response.json())
        .then(data => {
            let sugestoes = data.map(equipamento => `<div onclick="selecionarEquipamento('${equipamento.nome_equipamento}', ${equipamento.id_equip})">${equipamento.nome_equipamento}</div>`).join('');
            document.getElementById('sugestoesEquipamentos').innerHTML = sugestoes;
        });
}

function selecionarEquipamento(nomeEquipamento, idEquipamento) {
    document.getElementById('equipamento').value = nomeEquipamento;
    document.getElementById('equipamentoId').value = idEquipamento;
    document.getElementById('sugestoesEquipamentos').innerHTML = '';
}

function buscarTecnico(query) {
    if (query.length === 0) {
        document.getElementById('sugestoesTecnicos').innerHTML = '';
        return;
    }
    fetch(`/busca_tecnico?q=${query}`)
        .then(response => response.json())
        .then(data => {
            let sugestoes = data.map(tecnico => `<div onclick="selecionarTecnico('${tecnico.nome_tecnico}', ${tecnico.id_tec})">${tecnico.nome_tecnico}</div>`).join('');
            document.getElementById('sugestoesTecnicos').innerHTML = sugestoes;
        });
}

function selecionarTecnico(nomeTecnico, idTecnico) {
    document.getElementById('tecnico').value = nomeTecnico;
    document.getElementById('tecnicoId').value = idTecnico;
    document.getElementById('sugestoesTecnicos').innerHTML = '';
}