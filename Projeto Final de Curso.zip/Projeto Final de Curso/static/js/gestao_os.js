function mostrarFormulario(id_os, status_atual) {
    document.getElementById('form-editar-' + id_os).style.display = 'block';
    document.getElementById('status-atual-' + id_os).value = status_atual;
    document.getElementById('id-os-editar').value = id_os;
}