function searchClient(query) {
    if (query.length === 0) {
        document.getElementById('suggestions').innerHTML = '';
        return;
    }
    fetch(`/busca_cliente?q=${query}`)
        .then(response => response.json())
        .then(data => {
            let suggestions = data.map(client => `<div onclick="selectClient('${client.nome}', ${client.id_cli})">${client.nome}</div>`).join('');
            document.getElementById('suggestions').innerHTML = suggestions;
        });
}

function selectClient(clientName, clientId) {
    document.getElementById('cliente').value = clientName;
    document.getElementById('cliente_id').value = clientId;
    document.getElementById('suggestions').innerHTML = '';
}