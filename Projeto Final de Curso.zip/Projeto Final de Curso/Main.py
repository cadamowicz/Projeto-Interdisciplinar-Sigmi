from flask import Flask, render_template, redirect, request,jsonify,flash,session
from SQL.conexaodb import verificalogin, buscadadosperfil,inserir_cliente,busca_clientes,insere_equipamento,insere_tecnico
from SQL.conexaodb import inserir_ordem_servico, busca_equipamentos, busca_tecnicos,buscar_ordens_servico
from SQL.conexaodb import atualizar_status_ordem_servico

app = Flask(__name__)
app.secret_key = '*123#'


@app.route('/')  #rota carregamento inicial html
def home():
    return render_template('login.html')

@app.route('/menu')  #rota carregamento menu html
def menu():    
    return render_template('menu.html')

@app.route('/login')  #rota carregamento login html
def loginn():
    return render_template('login.html')

@app.route('/cadastroclientes')  #rota carregamento cadastro de clientes html
def rotacadastroclientes():
    return render_template('cadastroclientes.html')

@app.route('/cadastroequipamentos')  #rota carregamento cadastro equipamentos
def rotacadastroequipamentos():
    return render_template('cadastroequipamentos.html')

@app.route('/cadastrotecnico')  #rota carregamento cadastro de tecnico
def rotacadastrotecnico():
    return render_template('cadastrotecnico.html')

@app.route('/cadastro_os')  #rota carregamento cadastro de os
def rotacadastro_os():
    return render_template('cadastro_os.html')


@app.route('/gestaodeos')
def gestao_os():
    ordens = buscar_ordens_servico()
    
    # Organizar ordens por status
    ordens_por_status = {
        "Entrada": [],
        "Analise": [],
        "Manutencao": [],
        "Concluido": []
    }
    
    for ordem in ordens:
        status_nome = ordem[3] if ordem[3] else "Desconhecido"
        if status_nome in ordens_por_status:
            ordens_por_status[status_nome].append(ordem)
    
    return render_template('gestaodeos.html', ordens_servico=ordens_por_status)

@app.route('/editar_status', methods=['POST'])
def editar_status():
    id_os = request.form.get('id_os')
    novo_status = request.form.get('novo_status')

    try:
        atualizar_status_ordem_servico(id_os, novo_status)
        alert_message = "Status atualizado com sucesso!"
        alert_type = "success"
    except Exception as e:
        alert_message = "Erro ao atualizar status: " + str(e)
        alert_type = "error"

    return redirect(('/gestaodeos'))



@app.route('/consulta_historico')
def consulta_historico():
    return render_template('consulta_historico.html')


@app.route('/perfil') #rota carregamento perfil html
def perfil():
    
    dadosdocliente=buscadadosperfil()    
    field_names = ['RAZAO SOCIAL', 'CNPJ','NOME FANTASIA','ENDERECO','NUMERO','CEP','BAIRRO','CIDADE','ESTADO','COMPLEMENTO']  # Campos para Unificar
    fields_data = []
    for row in dadosdocliente:  
        if isinstance(row, int) == True:
            convertido=str(row)
            fields_data.append(dict(zip(field_names, convertido)))

        else:  
        
            fields_data.append(dict(zip(field_names, row)))
    for teste in fields_data:
        print(teste)
    return render_template('perfil.html', fields_data=fields_data)   


@app.route('/login', methods=['POST', 'GET'])
def login():
    nome = request.form.get('nome')
    senha = request.form.get('senha')        

    login = verificalogin(nome, senha)    # Passando nome e senha por parâmetro para verificação

    if login:
        return redirect('/menu')        
    else:
        flash('Nome ou senha incorretos, tente novamente.')
        return redirect('/login')
    
@app.route('/cadastroclientes', methods=['POST'])  # cadastro de clientes
def cadastro():
    tipo_cliente = request.form.get('tipocliente')
    sucesso = False
    
    try:
        if tipo_cliente == 'fisica':
            nome = request.form.get('nome')
            cpf = request.form.get('cpf')
            email = request.form.get('email_pf')
            telefone = request.form.get('telefone')
            endereco_rua = request.form.get('endereco')
            endereco_num = request.form.get('numero')
            endereco_bairro = request.form.get('bairro')
            endereco_cep = request.form.get('cep')
            endereco_cidade = request.form.get('cidade')
            endereco_estado = request.form.get('estado')
            endereco_complemento = request.form.get('complemento')
            sucesso = inserir_cliente('fisica', nome, cpf, email, telefone, None, None, None, endereco_rua, endereco_num, endereco_bairro, endereco_cep, endereco_cidade, endereco_estado, endereco_complemento)

        elif tipo_cliente == 'juridica':
            cnpj = request.form.get('cnpj')
            razao_social = request.form.get('razao_social')
            nome_fantasia = request.form.get('nome_fantasia')
            email = request.form.get('email_pj')
            telefone = request.form.get('telefone_pj')
            endereco_rua = request.form.get('endereco_pj')
            endereco_num = request.form.get('numero_pj')
            endereco_bairro = request.form.get('bairro_pj')
            endereco_cep = request.form.get('cep_pj')
            endereco_cidade = request.form.get('cidade_pj')
            endereco_estado = request.form.get('estado_pj')
            endereco_complemento = request.form.get('complemento_pj')
            sucesso = inserir_cliente('juridica', None, None, email, telefone, cnpj, razao_social, nome_fantasia, endereco_rua, endereco_num, endereco_bairro, endereco_cep, endereco_cidade, endereco_estado, endereco_complemento)

        if sucesso:
            flash('Cliente cadastrado com sucesso!', 'success')
        else:
            flash('Erro ao cadastrar cliente. Tente novamente.', 'danger')
    except Exception as e:
        flash(f'Erro ao cadastrar cliente: {str(e)}', 'danger')

    return redirect('/cadastroclientes')


@app.route('/cadastroequipamentos', methods=['GET', 'POST'])
def cadastro_equipamento():
    if request.method == 'POST':
        nome_equipamento = request.form.get('nomeEquipamento')
        num_serie = request.form.get('numeroSerie')
        memoria = request.form.get('memoria')
        armazenamento = request.form.get('armazenamento')
        processador = request.form.get('processador')
        observacoes = request.form.get('observacoes')
        id_cliente = request.form.get('cliente_id')

        try:
            insere_equipamento(nome_equipamento, num_serie, memoria, armazenamento, processador, observacoes, id_cliente)
            flash('Equipamento cadastrado com sucesso!', 'success')
        except Exception as e:
            flash(f'Erro ao cadastrar o equipamento: {str(e)}', 'danger')
        
        return redirect('/cadastroequipamentos')
    
    return render_template('cadastro_equipamento.html')

@app.route('/busca_cliente') #Rota para buscar cliente no banco
def busca_cliente():
    query = request.args.get('q') #Captura o valor do parâmetro de consulta
    if query:
        results = busca_clientes(query) #Verifica se o parâmetro q foi passado e não está vazio
        return jsonify(results) #Chama a função busca_clientes passando a consulta (query) como argumento. Esta função procura no banco de dados clientes que correspondem ao critério de pesquisa e retornar os resultados.
    return jsonify([])  # Retorna uma lista vazia se nenhum parâmetro de consulta foi passado!

@app.route('/cadastrotecnico', methods=['POST'])  # Rota para cadastro de técnico
def cadastrar_tecnico():
    nome_tecnico = request.form['nomeTecnico']
    if nome_tecnico:  # Verifica se o campo nome_tecnico contém um valor
        if insere_tecnico(nome_tecnico):  # Chama a função e verifica sucesso
            flash('Técnico cadastrado com sucesso!', 'success')
        else:
            flash('Erro ao cadastrar técnico. Tente novamente.', 'danger')
    else:
        flash('O nome do técnico é obrigatório!', 'danger')
    
    return redirect('/cadastrotecnico')


@app.route('/busca_equipamento') # Rota para buscar equipamento no banco
def busca_equipamento():
    query = request.args.get('q') # Captura o valor do parâmetro de consulta
    if query:
        results = busca_equipamentos(query) # Verifica se o parâmetro q foi passado e não está vazio
        return jsonify(results) # Retorna os resultados da busca de equipamentos
    return jsonify([])

@app.route('/busca_tecnico') # Rota para buscar técnico no banco
def busca_tecnico():
    query = request.args.get('q') # Captura o valor do parâmetro de consulta
    if query:
        results = busca_tecnicos(query) # Verifica se o parâmetro q foi passado e não está vazio
        return jsonify(results) # Retorna os resultados da busca de técnicos
    return jsonify([])



@app.route('/cadastro_os', methods=['POST'])
def cadastrar_ordem_servico():
    data_inicio = request.form.get('data_inicio')
    data_final = request.form.get('data_final')
    cliente_id = request.form.get('clienteId')
    equipamento_id = request.form.get('equipamentoId')
    tecnico_id = request.form.get('tecnicoId')
    status = request.form.get('status')
    evolucao = request.form.get('evolucao')

    status_map = {
        "Entrada": 1,
        "Analise": 2,
        "Manutencao": 3,
        "Concluido": 4
    }

    status_id = status_map.get(status, 0)

    print(f"Status recebido: {status}, ID mapeado: {status_id}")

    # Verificação das datas
    if data_inicio > data_final:
        alert_message = "Erro: A data de saída não pode ser menor que a data de entrada."
        alert_type = "error"
        return render_template('cadastro_os.html', alert_message=alert_message, alert_type=alert_type)

    try:
        inserir_ordem_servico(data_inicio, data_final, cliente_id, equipamento_id, tecnico_id, status_id, evolucao)
        alert_message = "Ordem de serviço cadastrada com sucesso!"
        alert_type = "success"
    except Exception as e:
        alert_message = "Erro ao cadastrar ordem de serviço: " + str(e)
        alert_type = "error"

    return render_template('cadastro_os.html', alert_message=alert_message, alert_type=alert_type)



app.route('/gestaodeos')
def gestao_os():
    ordens = buscar_ordens_servico()
    
    ordens_por_status = {
        "Entrada": [],
        "Analise": [],
        "Manutencao": [],
        "Concluido": []
    }
    
    for ordem in ordens:
        status_nome = ordem[3] if ordem[3] else "Desconhecido"
        if status_nome in ordens_por_status:
            ordens_por_status[status_nome].append(ordem)
    
    return render_template('gestaodeos.html', ordens_servico=ordens_por_status)       
    
            



if __name__ in "__main__":
    
    app.run(debug=True)